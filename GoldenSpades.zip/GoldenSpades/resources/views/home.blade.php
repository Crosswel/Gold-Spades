<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GoldSpades - Home</title>
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body>

    <!-- Menu Lateral -->
    @include('partials.menu')

    <!-- Cabeçalho -->
    <header>
        <div class="top-bar">Portes grátis em Encomendas acima de 75€</div>

        <div class="header-content">
            <div class="menu-button" onclick="toggleMenu()">☰</div>

            <a href="{{ route('home') }}">
                <img src="{{ asset('images/Logo.PNG') }}" alt="GoldSpades" class="logo">
            </a>

            <div class="header-icons">
                <div class="search-container">
                    <button class="search-icon" onclick="toggleSearch()">🔍</button>
                    <form id="searchForm" action="{{ route('search') }}" method="GET" style="display: none;">
                        <input type="text" name="q" placeholder="Procurar produto..." required>
                        <button type="submit">🔎</button>
                    </form>
                </div>

                <button onclick="openLogin()">👤</button>
                <a href="{{ route('favoritos') }}">❤️</a>
                <button onclick="openCart()">🛒</button>
            </div>
        </div>
    </header>

    <!-- Galeria -->
    <div class="gallery">
        <h2>Relógios</h2>

        <div class="products-grid">
            @foreach($produtos as $produto)
                <div class="product-card">
                    <a href="{{ route('produto', ['id' => $produto->id]) }}">
                        <img src="{{ asset('storage/' . $produto->imagem) }}" alt="{{ $produto->nome }}">
                    </a>
                    <p>{{ $produto->nome }}</p>
                </div>
            @endforeach
        </div>
    </div>

    <!-- Login e Registo -->
    @include('partials.login-register')

    <!-- Scripts -->
    <script>
        function toggleMenu() {
            document.getElementById('sideMenu').classList.toggle('active');
            document.getElementById('menuOverlay').classList.toggle('active');
        }

        function closeMenu() {
            document.getElementById('sideMenu').classList.remove('active');
            document.getElementById('menuOverlay').classList.remove('active');
        }

        function openLogin() {
            document.getElementById('loginPanel').style.width = '300px';
            document.getElementById('overlay').style.display = 'block';
        }

        function closeLogin() {
            document.getElementById('loginPanel').style.width = '0';
            document.getElementById('overlay').style.display = 'none';
        }

        function openRegister() {
            document.getElementById('registerPanel').style.width = '300px';
            document.getElementById('overlay').style.display = 'block';
        }

        function closeRegister() {
            document.getElementById('registerPanel').style.width = '0';
            document.getElementById('overlay').style.display = 'none';
        }

        function closePanels() {
            closeLogin();
            closeRegister();
        }

        function toggleSearch() {
            var form = document.getElementById('searchForm');
            if (form.style.display === "none" || form.style.display === "") {
                form.style.display = "flex";
            } else {
                form.style.display = "none";
            }
        }

        function openCart() {
            alert("Abrir carrinho (Funcionalidade futura)");
        }
    </script>

</body>
</html>
