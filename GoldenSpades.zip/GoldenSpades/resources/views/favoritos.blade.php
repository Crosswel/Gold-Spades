<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Favoritos - GoldSpades</title>
    <link rel="stylesheet" href="{{ asset('css/site.css') }}">
</head>
<body>

    <div class="top-bar">
        Portes grátis em Encomendas acima de 75€
    </div>

    <div class="header">
        <div class="menu-icon" onclick="toggleMenu()">☰</div>
        <div class="logo">
            <a href="/">
                <img src="{{ asset('images/Logo.PNG') }}" alt="GoldSpades Logo" style="height: 80px;">
            </a>
        </div>
        <div class="icons">
            <div class="search-container">
                <input type="text" name="query" id="searchInput" class="search-input" placeholder="Procurar produto...">
                <button class="search-icon">🔍</button>
            </div>
            <span onclick="toggleLogin()">👤</span>
            <span onclick="window.location.href='/favoritos'">❤️</span>
            <span onclick="toggleCart()">🛒</span>
        </div>
    </div>

    <!-- Menu lateral -->
    <div class="side-menu" id="sideMenu">
        <span class="close-btn" onclick="toggleMenu()">✕</span>
        <h3>MENU</h3>
        <input class="search-bar" type="text" placeholder="🔍 Pesquisar">
        <ul>
            <li><a href="#">Relógios</a></li>
            <li><a href="#">Pulseiras</a></li>
            <li><a href="#">Anéis</a></li>
            <li><a href="#">Medalhas</a></li>
            <li><a href="{{ route('novacolecao') }}">Nova coleção</a></li>
            <li class="highlight"><a href="#">Promoções</a></li>
            <li><a href="#">Contactos</a></li>
            <li><a href="#">Faq’s</a></li>
        </ul>
        <div class="language">🌐 Português - Portugal</div>
    </div>
    <div class="menu-overlay" id="menuOverlay" onclick="closeMenu()"></div>

    <!-- Galeria de Favoritos -->
    <div class="gallery">
        <div>
            <a href="{{ route('produto') }}">
                <img src="{{ asset('images/fav1.jpg') }}" alt="Brincos">
            </a>
            <p style="text-align:center;">Brincos</p>
        </div>
        <div>
            <a href="{{ route('produto') }}">
                <img src="{{ asset('images/fav2.jpg') }}" alt="Colar">
            </a>
            <p style="text-align:center;">Colar</p>
        </div>
        <div>
            <a href="{{ route('produto') }}">
                <img src="{{ asset('images/fav3.jpg') }}" alt="Anel">
            </a>
            <p style="text-align:center;">Anel</p>
        </div>
        <div>
            <a href="{{ route('produto') }}">
                <img src="{{ asset('images/fav4.jpg') }}" alt="Pulseiras">
            </a>
            <p style="text-align:center;">Pulseiras</p>
        </div>
    </div>

    <!-- Scripts -->
    <script>
        function toggleMenu() {
            const menu = document.getElementById('sideMenu');
            const overlay = document.getElementById('menuOverlay');
            menu.classList.toggle('open');
            overlay.classList.toggle('visible');
        }

        function closeMenu() {
            document.getElementById('sideMenu').classList.remove('open');
            document.getElementById('menuOverlay').classList.remove('visible');
        }

        function toggleLogin() {
            alert("Abrir painel de login");
        }

        function toggleCart() {
            alert("Abrir carrinho");
        }

        document.querySelector('.search-icon').addEventListener('click', function (e) {
            const container = document.querySelector('.search-container');
            const input = document.querySelector('#searchInput');

            if (container.classList.contains('active') && input.value.trim() !== '') {
                const form = document.createElement('form');
                form.action = "{{ route('produtos.pesquisar') }}";
                form.method = 'GET';

                const inputHidden = document.createElement('input');
                inputHidden.type = 'hidden';
                inputHidden.name = 'query';
                inputHidden.value = input.value;

                form.appendChild(inputHidden);
                document.body.appendChild(form);
                form.submit();
            } else {
                container.classList.toggle('active');
                input.focus();
            }

            e.stopPropagation();
        });

        document.addEventListener('click', function (e) {
            const container = document.querySelector('.search-container');
            const input = document.querySelector('#searchInput');
            if (!container.contains(e.target)) {
                container.classList.remove('active');
                input.value = '';
            }
        });
    </script>
</body>
</html>
