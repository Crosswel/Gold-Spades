<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GoldSpades - Home</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
</head>
<body>

    <!-- Menu Lateral -->
    <?php echo $__env->make('partials.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Cabeçalho -->
    <header>
        <div class="top-bar">Portes grátis em Encomendas acima de 75€</div>

        <div class="header-content">
            <div class="menu-button" onclick="toggleMenu()">☰</div>

            <a href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/Logo.PNG')); ?>" alt="GoldSpades" class="logo">
            </a>

            <div class="header-icons">
                <div class="search-container">
                    <button class="search-icon" onclick="toggleSearch()">🔍</button>
                    <form id="searchForm" action="<?php echo e(route('search')); ?>" method="GET" style="display: none;">
                        <input type="text" name="q" placeholder="Procurar produto..." required>
                        <button type="submit">🔎</button>
                    </form>
                </div>

                <button onclick="openLogin()">👤</button>
                <a href="<?php echo e(route('favoritos')); ?>">❤️</a>
                <button onclick="openCart()">🛒</button>
            </div>
        </div>
    </header>

    <!-- Galeria -->
    <div class="gallery">
        <h2>Relógios</h2>

        <div class="products-grid">
            <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-card">
                    <a href="<?php echo e(route('produto', ['id' => $produto->id])); ?>">
                        <img src="<?php echo e(asset('storage/' . $produto->imagem)); ?>" alt="<?php echo e($produto->nome); ?>">
                    </a>
                    <p><?php echo e($produto->nome); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Login e Registo -->
    <?php echo $__env->make('partials.login-register', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Scripts -->
    <script>
        function toggleMenu() {
            document.getElementById('sideMenu').classList.toggle('active');
            document.getElementById('menuOverlay').classList.toggle('active');
        }

        function closeMenu() {
            document.getElementById('sideMenu').classList.remove('active');
            document.getElementById('menuOverlay').classList.remove('active');
        }

        function openLogin() {
            document.getElementById('loginPanel').style.width = '300px';
            document.getElementById('overlay').style.display = 'block';
        }

        function closeLogin() {
            document.getElementById('loginPanel').style.width = '0';
            document.getElementById('overlay').style.display = 'none';
        }

        function openRegister() {
            document.getElementById('registerPanel').style.width = '300px';
            document.getElementById('overlay').style.display = 'block';
        }

        function closeRegister() {
            document.getElementById('registerPanel').style.width = '0';
            document.getElementById('overlay').style.display = 'none';
        }

        function closePanels() {
            closeLogin();
            closeRegister();
        }

        function toggleSearch() {
            var form = document.getElementById('searchForm');
            if (form.style.display === "none" || form.style.display === "") {
                form.style.display = "flex";
            } else {
                form.style.display = "none";
            }
        }

        function openCart() {
            alert("Abrir carrinho (Funcionalidade futura)");
        }
    </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\GoldenSpades\resources\views/home.blade.php ENDPATH**/ ?>