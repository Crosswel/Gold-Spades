<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Nova Coleção - GoldSpades</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
</head>
<body>

    <div class="top-bar">
        Portes grátis em Encomendas acima de 75€
    </div>

    <div class="header">
        <div class="menu-icon" onclick="toggleMenu()">☰</div>
        <div class="logo">
            <a href="/">
                <img src="<?php echo e(asset('images/Logo.PNG')); ?>" alt="GoldSpades Logo" style="height: 80px;">
            </a>
        </div>
        <div class="icons">
            <div class="search-container">
                <input type="text" name="query" id="searchInput" class="search-input" placeholder="Procurar produto...">
                <button class="search-icon">🔍</button>
            </div>
            <span onclick="toggleLogin()">👤</span>
            <span onclick="window.location.href='/favoritos'">❤️</span>
            <span onclick="toggleCart()">🛒</span>
        </div>
    </div>

    <!-- Menu lateral -->
    <div class="side-menu" id="sideMenu">
        <span class="close-btn" onclick="toggleMenu()">✕</span>
        <h3>MENU</h3>
        <input class="search-bar" type="text" placeholder="🔍 Pesquisar">
        <ul>
            <li><a href="#">Relógios</a></li>
            <li><a href="#">Pulseiras</a></li>
            <li><a href="#">Anéis</a></li>
            <li><a href="#">Medalhas</a></li>
            <li><a href="<?php echo e(route('novacolecao')); ?>">Nova coleção</a></li>
            <li class="highlight"><a href="#">Promoções</a></li>
            <li><a href="#">Contactos</a></li>
            <li><a href="#">Faq’s</a></li>
        </ul>
        <div class="language">🌐 Português - Portugal</div>
    </div>
    <div class="menu-overlay" id="menuOverlay" onclick="closeMenu()"></div>

    <!-- Conteúdo Nova Coleção -->
    <div class="gallery">
        <div class="gallery-title" style="width: 100%; text-align: left; padding: 0 40px;">
            <h2 style="color: #7b5a16;">Nova Coleção</h2>
        </div>

        <div class="gallery" style="margin-top: 20px;">
            <div>
                <a href="<?php echo e(route('produto')); ?>">
                    <img src="<?php echo e(asset('images/colecao1.jpg')); ?>" alt="Nova Coleção Principal">
                </a>
            </div>
            <div>
                <a href="<?php echo e(route('produto')); ?>">
                    <img src="<?php echo e(asset('images/pulseira1.jpg')); ?>" alt="Pulseira">
                </a>
                <p style="text-align: center;">Pulseira</p>
            </div>
            <div>
                <a href="<?php echo e(route('produto')); ?>">
                    <img src="<?php echo e(asset('images/pulseira2.jpg')); ?>" alt="Pulseira 2">
                </a>
                <p style="text-align: center;">Pulseira</p>
            </div>
            <div>
                <a href="<?php echo e(route('produto')); ?>">
                    <img src="<?php echo e(asset('images/colar.jpg')); ?>" alt="Colar">
                </a>
                <p style="text-align: center;">Colar</p>
            </div>
            <div>
                <a href="<?php echo e(route('produto')); ?>">
                    <img src="<?php echo e(asset('images/brincos.jpg')); ?>" alt="Brincos">
                </a>
                <p style="text-align: center;">Brincos</p>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script>
        function toggleMenu() {
            const menu = document.getElementById('sideMenu');
            const overlay = document.getElementById('menuOverlay');
            menu.classList.toggle('open');
            overlay.classList.toggle('visible');
        }

        function closeMenu() {
            document.getElementById('sideMenu').classList.remove('open');
            document.getElementById('menuOverlay').classList.remove('visible');
        }

        function toggleLogin() {
            alert("Abrir painel de login");
        }

        function toggleCart() {
            alert("Abrir carrinho");
        }

        document.querySelector('.search-icon').addEventListener('click', function (e) {
            const container = document.querySelector('.search-container');
            const input = document.querySelector('#searchInput');

            if (container.classList.contains('active') && input.value.trim() !== '') {
                const form = document.createElement('form');
                form.action = "<?php echo e(route('produtos.pesquisar')); ?>";
                form.method = 'GET';

                const inputHidden = document.createElement('input');
                inputHidden.type = 'hidden';
                inputHidden.name = 'query';
                inputHidden.value = input.value;

                form.appendChild(inputHidden);
                document.body.appendChild(form);
                form.submit();
            } else {
                container.classList.toggle('active');
                input.focus();
            }

            e.stopPropagation();
        });

        document.addEventListener('click', function (e) {
            const container = document.querySelector('.search-container');
            const input = document.querySelector('#searchInput');
            if (!container.contains(e.target)) {
                container.classList.remove('active');
                input.value = '';
            }
        });
    </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\GoldenSpades\resources\views/novacolecao.blade.php ENDPATH**/ ?>