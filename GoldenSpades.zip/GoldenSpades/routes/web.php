<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dbconn', function(){
    return view('dbconn');
});
Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});

Route::get('/', function () {
    return view('home');
});

Route::get('/favoritos', function () {
    return view('favoritos');
});

use App\Http\Controllers\ProdutoController;

Route::get('/relogios', [ProdutoController::class, 'relogios'])->name('relogios');

Route::get('/pesquisar', [ProdutoController::class, 'pesquisar'])->name('produtos.pesquisar');

Route::get('/novacolecao', function () {
    return view('novacolecao');
})->name('novacolecao');

Route::get('/produto', function () {
    return view('produto');
})->name('produto');

use App\Http\Controllers\HomeController;

Route::get('/', [HomeController::class, 'index'])->name('home');
